package id.kinerjaku.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.DocumentsContract;

import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER=3001;
    private LinearLayout content;
    private TextView status, stats;
    private Button pick;

    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s);v.setTextSize(size);v.setTextColor(color);
        v.setPadding(dp(4),dp(5),dp(4),dp(5)); return v;
    }
    LinearLayout card(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16),dp(16),dp(16),dp(16));
        GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(dp(14));g.setStroke(dp(1),Color.rgb(225,230,238));c.setBackground(g);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(12));c.setLayoutParams(lp);
        return c;
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);build();}

    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(244,246,249));
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18),dp(18),dp(18),dp(16));header.setBackgroundColor(Color.rgb(23,59,114));
        TextView title=text("KinerjaKu",23,Color.WHITE);title.setTypeface(null,Typeface.BOLD);
        header.addView(title);header.addView(text("Daily Snapshot • PSR Offline",14,Color.WHITE));root.addView(header);

        ScrollView scroll=new ScrollView(this);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(14),dp(14),dp(90));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout imp=card();
        imp.addView(text("Import Folder PSR",21,Color.rgb(23,32,51)));
        imp.addView(text("Pilih folder laporan harian yang berisi seluruh file .PSR. Tidak membutuhkan PC, server, RAR, atau internet.",13,Color.DKGRAY));
        pick=new Button(this);pick.setText("📂  PILIH FOLDER PSR");pick.setOnClickListener(v->chooseFolder());imp.addView(pick);
        status=text("Belum ada snapshot.",13,Color.GRAY);imp.addView(status);content.addView(imp);

        LinearLayout dash=card();dash.addView(text("Snapshot",18,Color.rgb(23,32,51)));
        stats=text("File PSR: 0\\nJenis laporan: 0",14,Color.DKGRAY);dash.addView(stats);content.addView(dash);

        setContentView(root);
    }

    void chooseFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i,PICK_FOLDER);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK_FOLDER && result==RESULT_OK && data!=null && data.getData()!=null){
            Uri tree=data.getData();
            try{
                getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }catch(Exception ignored){}
            pick.setEnabled(false);
            status.setText("⏳ Membaca folder dan seluruh PSR...");
            new Thread(()->processFolder(tree)).start();
        }
    }

    void processFolder(Uri tree){
        List<PsrAnalyzer.Result> results=new ArrayList<>();
        try{
            scanTree(tree,results);
            Map<String,Integer> counts=new LinkedHashMap<>();
            for(PsrAnalyzer.Result r:results)counts.put(r.code,counts.getOrDefault(r.code,0)+1);
            final String folderName=folderName(tree);
            runOnUiThread(()->showResults(folderName,results,counts));
        }catch(Exception e){
            final String msg=e.getMessage()==null?e.toString():e.getMessage();
            runOnUiThread(()->{pick.setEnabled(true);status.setText("❌ Import gagal: "+msg);});
        }
    }

    void scanTree(Uri tree,List<PsrAnalyzer.Result> results)throws Exception{
        scanDocument(tree,results);
    }

    void scanDocument(Uri doc,List<PsrAnalyzer.Result> results)throws Exception{
        String[] projection={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(doc,DocumentsContract.getTreeDocumentId(doc));
        try(android.database.Cursor c=getContentResolver().query(children,projection,null,null,null)){
            if(c==null)return;
            while(c.moveToNext()){
                String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
                Uri child=DocumentsContract.buildDocumentUriUsingTree(doc,id);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){
                    scanDocument(child,results);
                }else if(name!=null && name.toLowerCase(Locale.ROOT).endsWith(".psr")){
                    File tmp=new File(getCacheDir(),"psr_"+System.nanoTime()+".psr");
                    try(InputStream in=getContentResolver().openInputStream(child);OutputStream out=new FileOutputStream(tmp)){
                        if(in==null)continue;byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                    }
                    try{results.add(PsrAnalyzer.analyze(tmp));}finally{tmp.delete();}
                }
            }
        }
    }

    void showResults(String folder,List<PsrAnalyzer.Result> results,Map<String,Integer> counts){
        pick.setEnabled(true);
        status.setText("✅ Snapshot "+folder+" selesai • "+results.size()+" PSR terbaca");
        StringBuilder s=new StringBuilder();
        s.append("Folder: ").append(folder).append("\\n");
        s.append("File PSR: ").append(results.size()).append("\\n");
        s.append("Jenis laporan: ").append(counts.size()).append("\\n\\n");
        for(Map.Entry<String,Integer> e:counts.entrySet())
            s.append(e.getKey()).append(" — ").append(PsrAnalyzer.REPORTS.getOrDefault(e.getKey(),"PSR belum dipetakan"))
             .append(" : ").append(e.getValue()).append(" file\\n");
        stats.setText(s.toString());

        LinearLayout detail=card();detail.addView(text("PSR Terbaca",18,Color.rgb(23,32,51)));
        for(PsrAnalyzer.Result r:results){
            TextView row=text(r.file+"\\n"+r.code+" • "+r.type+"\\nKolom DataWindow: "+r.columns.size(),13,Color.DKGRAY);
            row.setPadding(dp(4),dp(9),dp(4),dp(9));detail.addView(row);
        }
        content.addView(detail,2);
    }

    String folderName(Uri tree){
        String s=tree.toString();int p=s.lastIndexOf('/');
        return p>=0?s.substring(p+1):"Snapshot";
    }
}
