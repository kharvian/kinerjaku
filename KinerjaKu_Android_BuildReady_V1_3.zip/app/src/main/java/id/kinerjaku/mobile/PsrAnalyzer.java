package id.kinerjaku.mobile;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public final class PsrAnalyzer {
    private PsrAnalyzer() {}

    public static final Map<String,String> REPORTS = new LinkedHashMap<>();
    static {
        REPORTS.put("D001","Neraca Harian");
        REPORTS.put("D002","Laba Rugi Harian XBRL");
        REPORTS.put("D003","Rincian Neraca");
        REPORTS.put("D004","Rincian Laba Rugi");
        REPORTS.put("D052","Laporan Operasional");
        REPORTS.put("D152","Tabungan Wadiah");
        REPORTS.put("D153","Tabungan Mudharabah");
        REPORTS.put("D205","Deposito");
        REPORTS.put("D252","Pembiayaan");
        REPORTS.put("B007","Laporan Dana/Transaksi");
    }

    public static Result analyze(File file) throws IOException {
        byte[] raw = readAll(file);
        String text = decodeBest(raw);
        String code = codeOf(file.getName());
        List<String> columns = new ArrayList<>();
        Matcher cm = Pattern.compile(
            "column=\\(type=.*?name=([A-Za-z0-9_]+)\\s+dbname=\"([^\"]+)\"",
            Pattern.DOTALL).matcher(text);
        while (cm.find() && columns.size() < 150) {
            columns.add(cm.group(1) + " → " + cm.group(2));
        }

        LinkedHashSet<String> units = new LinkedHashSet<>();
        Matcher um = Pattern.compile("KANTOR[^\\u0000\\r\\n]{2,100}", Pattern.CASE_INSENSITIVE).matcher(text);
        while (um.find() && units.size() < 10) units.add(clean(um.group()));

        LinkedHashSet<String> dates = new LinkedHashSet<>();
        Matcher dm = Pattern.compile("\\b\\d{1,2}\\s+(?:JANUARI|FEBRUARI|MARET|APRIL|MEI|JUNI|JULI|AGUSTUS|SEPTEMBER|OKTOBER|NOVEMBER|DESEMBER)\\s+\\d{4}\\b", Pattern.CASE_INSENSITIVE).matcher(text);
        while (dm.find() && dates.size() < 5) dates.add(dm.group());

        return new Result(file.getName(), code, REPORTS.getOrDefault(code,"PSR belum dipetakan"),
                file.length(), columns, new ArrayList<>(units), new ArrayList<>(dates));
    }

    static String decodeBest(byte[] raw) {
        String a = new String(raw, StandardCharsets.UTF_16LE);
        if (printable(a) > 0.12) return a;
        return new String(raw, StandardCharsets.ISO_8859_1);
    }

    static double printable(String s) {
        if (s.isEmpty()) return 0;
        int n=0;
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c=='\n'||c=='\r'||c=='\t'||(c>=32&&c<127)||c>=160)n++;
        }
        return (double)n/s.length();
    }

    static String clean(String s) {
        return s.replace('\u0000',' ').replaceAll("\\s+"," ").trim();
    }

    static String codeOf(String name) {
        Matcher m=Pattern.compile("RPT_([A-Z]\\d{3})",Pattern.CASE_INSENSITIVE).matcher(name);
        return m.find()?m.group(1).toUpperCase(Locale.ROOT):"UNKNOWN";
    }

    static byte[] readAll(File f) throws IOException {
        try(InputStream in=new BufferedInputStream(new FileInputStream(f));
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[1024*1024]; int n;
            while((n=in.read(b))!=-1) out.write(b,0,n);
            return out.toByteArray();
        }
    }

    public static final class Result {
        public final String file, code, type;
        public final long size;
        public final List<String> columns, units, dates;
        Result(String file,String code,String type,long size,List<String> columns,List<String> units,List<String> dates){
            this.file=file;this.code=code;this.type=type;this.size=size;
            this.columns=columns;this.units=units;this.dates=dates;
        }
    }
}
