# Build APK KinerjaKu

## Tanpa Android Studio
Upload isi project ini ke GitHub sebagai repository, branch `main`.
Buka **Actions → Build KinerjaKu APK → Run workflow**.
Setelah selesai, buka **Artifacts → KinerjaKu-debug** dan download APK.

## Dengan Android Studio
Open folder project → tunggu Gradle Sync → Build → Build APK(s).
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Pemakaian
Pasang APK di Android → buka KinerjaKu → **PILIH FOLDER PSR** → pilih folder harian seperti `22-09-2026`.
Aplikasi berjalan offline dan tidak membutuhkan PC/server.

Catatan: versi ini sudah menjadi fondasi folder snapshot. Mapping angka kolektabilitas/outstanding per rekening masih harus divalidasi dari isi PSR sebelum digunakan sebagai laporan resmi.
