# KinerjaKu Android Offline

Project Android native untuk KinerjaKu.

## Fitur V1.1
- Tidak membutuhkan PC/server saat digunakan.
- Tidak membutuhkan internet saat digunakan.
- File picker Android.
- Import ZIP.
- Import RAR/RAR5 melalui Junrar.
- Ekstraksi seluruh arsip langsung di HP.
- Mencari seluruh file `.PSR`.
- Identifikasi kode laporan RPT_B007, RPT_D001, RPT_D002, RPT_D003, RPT_D004, RPT_D052, RPT_D152, RPT_D153, RPT_D205, RPT_D252.
- Membaca sebagian struktur DataWindow PSR: kolom, kandidat unit, dan tanggal.
- Dashboard ringkasan hasil import.

## Membuat APK
Project membutuhkan Android Studio / Android SDK.

1. Buka folder project ini di Android Studio.
2. Tunggu Gradle Sync.
3. Pilih `Build > Build APK(s)`.
4. APK debug biasanya berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Catatan parser
Versi ini sudah menangani alur `RAR/ZIP -> PSR` secara lokal. Pemetaan angka ke indikator kinerja (DPK, pembiayaan, NPF, laba, aset, target/realisasi) masih perlu diselesaikan berdasarkan struktur record/data yang ada pada masing-masing PSR. Jangan menganggap nama kolom saja sebagai nilai laporan.

## Rilis otomatis
Folder `.github/workflows/build-apk.yml` dapat digunakan untuk build APK di GitHub Actions tanpa memasang Android Studio di PC pengguna.


## Perubahan V1.2 — Folder PSR
Workflow utama sekarang:
1. Dari HP, tekan **PILIH FOLDER PSR**.
2. Pilih folder harian, misalnya `22-09-2026`.
3. Aplikasi membaca semua `.PSR`, termasuk subfolder.
4. Folder dianggap sebagai satu **snapshot harian**.
5. Snapshot berikutnya akan dibandingkan dengan snapshot sebelumnya setelah modul historis diaktifkan.

RAR/ZIP tidak lagi diperlukan untuk workflow utama.
