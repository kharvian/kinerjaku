package id.kinerjaku.mobile;

import android.content.*;import android.database.sqlite.*;import android.database.Cursor;import java.util.*;

public class SnapshotDb extends SQLiteOpenHelper{
 private static final String DB="kinerjaku.db"; private static final int VER=3;
 public SnapshotDb(Context c){super(c,DB,null,VER);}
 @Override public void onCreate(SQLiteDatabase d){create(d);}
 private void create(SQLiteDatabase d){
  d.execSQL("CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_name TEXT, imported_at INTEGER, file_count INTEGER)");
  d.execSQL("CREATE TABLE IF NOT EXISTS psr(id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER, file_name TEXT, code TEXT, title TEXT, size INTEGER, columns TEXT, candidates TEXT)");
  d.execSQL("CREATE TABLE IF NOT EXISTS financing(id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER, source_file TEXT, account_no TEXT, cif_name TEXT, no_nsb TEXT, akad TEXT, outstanding REAL, saldo_pokok REAL, kolek INTEGER, kol_nsb INTEGER, kol_rpt INTEGER, kolek_ll INTEGER, overdue_days INTEGER, ckpn REAL)");
  d.execSQL("CREATE INDEX IF NOT EXISTS idx_fin_snapshot ON financing(snapshot_id)");
  d.execSQL("CREATE INDEX IF NOT EXISTS idx_fin_account ON financing(account_no)");
 }
 @Override public void onUpgrade(SQLiteDatabase d,int o,int n){
  create(d);
  // V1.7 stored D252 fields with the old, shifted decoder. Reset those snapshots
  // so the first V1.8 import starts a clean 20 -> 21 -> 22 comparison chain.
  if(o<3){d.execSQL("DELETE FROM financing");d.execSQL("DELETE FROM psr");d.execSQL("DELETE FROM snapshots");}
 }
 public long saveSnapshot(String name,List<PsrAnalyzer.Result> rs){
  SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
  try{
   ContentValues s=new ContentValues();s.put("snapshot_name",name);s.put("imported_at",System.currentTimeMillis());s.put("file_count",rs.size());long id=d.insert("snapshots",null,s);
   for(PsrAnalyzer.Result r:rs){
    ContentValues v=new ContentValues();v.put("snapshot_id",id);v.put("file_name",r.file);v.put("code",r.code);v.put("title",r.type);v.put("size",r.size);v.put("columns",join(r.columns));v.put("candidates",join(r.candidates));d.insert("psr",null,v);
    for(PsrAnalyzer.FinancingRow x:r.financing){ContentValues f=new ContentValues();f.put("snapshot_id",id);f.put("source_file",r.file);f.put("account_no",x.account);f.put("cif_name",x.cif);f.put("no_nsb",x.noNsb);f.put("akad",x.akad);f.put("outstanding",x.outstanding);f.put("saldo_pokok",x.saldoPokok);f.put("kolek",x.kolek);f.put("kol_nsb",x.kolNsb);f.put("kol_rpt",x.kolRpt);f.put("kolek_ll",x.kolekLl);f.put("overdue_days",x.hariMenunggak);f.put("ckpn",x.ckpn);d.insert("financing",null,f);}
   }
   d.setTransactionSuccessful();return id;
  }finally{d.endTransaction();}
 }
 public int snapshotCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM snapshots",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
 public String previousSnapshotName(long latest){Cursor c=getReadableDatabase().rawQuery("SELECT snapshot_name FROM snapshots WHERE id < ? ORDER BY id DESC LIMIT 1",new String[]{String.valueOf(latest)});String s=null;if(c.moveToFirst())s=c.getString(0);c.close();return s;}
 public List<Movement> movements(long latest){
  ArrayList<Movement> out=new ArrayList<>();String prevId=null;Cursor pc=getReadableDatabase().rawQuery("SELECT id FROM snapshots WHERE id < ? ORDER BY id DESC LIMIT 1",new String[]{String.valueOf(latest)});if(pc.moveToFirst())prevId=pc.getString(0);pc.close();if(prevId==null)return out;
  String sql="SELECT n.account_no,n.cif_name,n.outstanding,n.kolek,p.kolek,n.kol_rpt,p.kol_rpt FROM financing n LEFT JOIN financing p ON p.snapshot_id=? AND p.account_no=n.account_no WHERE n.snapshot_id=? AND (p.account_no IS NULL OR n.kolek<>p.kolek OR n.outstanding<>p.outstanding) ORDER BY n.account_no";
  Cursor c=getReadableDatabase().rawQuery(sql,new String[]{prevId,String.valueOf(latest)});
  while(c.moveToNext())out.add(new Movement(c.getString(0),c.getString(1),c.getDouble(2),c.getInt(3),c.isNull(4)?0:c.getInt(4),c.getInt(5),c.isNull(6)?0:c.getInt(6),c.isNull(4)?"NEW":direction(c.getInt(4),c.getInt(3))));c.close();return out;
 }
 private String direction(int oldK,int newK){if(newK>oldK)return "MEMBURUK";if(newK<oldK)return "MEMBAIK";return "TETAP";}
 static String join(List<String>a){StringBuilder s=new StringBuilder();for(String x:a){if(s.length()>0)s.append("\n");s.append(x);}return s.toString();}
 public static final class Movement{public final String account,name,direction;public final double outstanding;public final int newK,oldK,newRpt,oldRpt;Movement(String a,String n,double o,int nk,int ok,int nr,int or,String d){account=a;name=n;outstanding=o;newK=nk;oldK=ok;newRpt=nr;oldRpt=or;direction=d;}}
}
