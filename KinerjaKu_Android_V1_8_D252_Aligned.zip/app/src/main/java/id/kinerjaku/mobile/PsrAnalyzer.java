package id.kinerjaku.mobile;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** PSR/DataWindow analyzer. D252 is decoded using the column schema embedded in the PSR header. */
public final class PsrAnalyzer {
    private PsrAnalyzer() {}
    public static final Map<String,String> REPORTS = new LinkedHashMap<>();
    static {
        REPORTS.put("D001","Neraca Harian"); REPORTS.put("D002","Laba Rugi Harian XBRL");
        REPORTS.put("D003","Rincian Neraca"); REPORTS.put("D004","Rincian Laba Rugi");
        REPORTS.put("D052","Laporan Operasional"); REPORTS.put("D152","Tabungan Wadiah");
        REPORTS.put("D153","Tabungan Mudharabah"); REPORTS.put("D205","Deposito");
        REPORTS.put("D252","Pembiayaan"); REPORTS.put("B007","Laporan Dana/Transaksi");
    }

    public static Result analyze(File file) throws IOException {
        byte[] raw=readAll(file); String text=decodeBest(raw);
        String code=codeOf(file.getName(),text), title=titleOf(code,text);
        List<ColumnDef> defs=parseColumns(text);
        List<String> columns=new ArrayList<>();
        for(ColumnDef d:defs) columns.add(d.name);
        LinkedHashSet<String> units=new LinkedHashSet<>(), dates=new LinkedHashSet<>();
        Matcher um=Pattern.compile("KANTOR[^\\u0000\\r\\n]{2,120}",Pattern.CASE_INSENSITIVE).matcher(text);
        while(um.find()&&units.size()<10) units.add(clean(um.group()));
        Matcher dm=Pattern.compile("\\b\\d{1,2}\\s+(?:JANUARI|FEBRUARI|MARET|APRIL|MEI|JUNI|JULI|AGUSTUS|SEPTEMBER|OKTOBER|NOVEMBER|DESEMBER)\\s+\\d{4}\\b",Pattern.CASE_INSENSITIVE).matcher(text);
        while(dm.find()&&dates.size()<10) dates.add(dm.group());
        List<String> candidates=new ArrayList<>();
        for(String c:columns){String lc=c.toLowerCase(Locale.ROOT); if(containsAny(lc,"kolek","kol_","outstanding","saldo","accnbr","no_nsb","cif","cifnm","nasabah","nomor_akad","hari_menunggak","ckpn")) candidates.add(c);}
        List<FinancingRow> financing="D252".equals(code)?parseD252(raw,defs):new ArrayList<FinancingRow>();
        return new Result(file.getName(),code,title,file.length(),columns,new ArrayList<>(units),new ArrayList<>(dates),candidates,financing);
    }

    private static List<ColumnDef> parseColumns(String text){
        ArrayList<ColumnDef> defs=new ArrayList<>();
        Pattern p=Pattern.compile("column=\\(type=([^\\s]+).*?name=([A-Za-z0-9_]+)",Pattern.CASE_INSENSITIVE);
        Matcher m=p.matcher(text);
        while(m.find() && defs.size()<500) defs.add(new ColumnDef(m.group(2),m.group(1)));
        return defs;
    }

    /**
     * D252 uses the DataWindow column order embedded in the PSR header. Each row starts
     * with FF FF FF FF 08 00 00 00, followed by a sequence of [uint32 length][payload].
     * Decimal(2)/Decimal(5) values are PowerBuilder 16-byte decimals; the low 64 bits
     * contain the scaled integer and the remaining bytes carry the PB decimal marker.
     */
    private static List<FinancingRow> parseD252(byte[] b,List<ColumnDef> defs){
        ArrayList<FinancingRow> out=new ArrayList<>();
        byte[] marker=new byte[]{(byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,8,0,0,0};
        int pos=0;
        while((pos=indexOf(b,marker,pos))>=0){
            int q=pos+8;
            String branch; branch=readU16z(b,q); q=nextU16z(b,q);
            Map<String,Object> row=new HashMap<>();
            boolean ok=true;
            // In PowerBuilder PSR, the branch/kd_cab value is stored once immediately
            // after the row marker. When the DataWindow schema also contains a
            // *_kd_cab column, that schema entry is therefore not repeated in the
            // per-column payload sequence. Skipping it keeps ACCNBR/CIFNM/etc.
            // aligned with their actual payloads.
            int startColumn = (!defs.isEmpty() && defs.get(0).name.toLowerCase(Locale.ROOT).contains("kd_cab")) ? 1 : 0;
            for(int di=startColumn; di<defs.size(); di++){
                ColumnDef d=defs.get(di);
                if(q+4>b.length){ok=false;break;}
                long len=u32(b,q); q+=4;
                if(len==0xffffffffL){row.put(d.name,null);continue;}
                if(len>Integer.MAX_VALUE || q+len>b.length){ok=false;break;}
                int n=(int)len;
                byte[] payload=Arrays.copyOfRange(b,q,q+n); q+=n;
                row.put(d.name,decodePayload(d.type,payload));
            }
            if(ok){
                String acc=s(row,"accnbr"), cif=s(row,"cifnm"), noNsb=s(row,"no_nsb"), akad=s(row,"nomor_akad");
                if(acc!=null && acc.trim().length()>2){
                    out.add(new FinancingRow(branch,acc.trim(),cleanNull(cif),cleanNull(noNsb),cleanNull(akad),
                            decimal(row,"saldo_akhir"),decimal(row,"saldo_pokok"),
                            integer(row,"kolek"),integer(row,"kol_nsb"),integer(row,"kol_rpt"),integer(row,"kolek_ll"),
                            integer(row,"hari_menunggak"),decimal(row,"ckpn")));
                }
            }
            pos=Math.max(pos+8,q);
        }
        return out;
    }

    private static Object decodePayload(String type,byte[] p){
        String t=type.toLowerCase(Locale.ROOT);
        if(t.startsWith("char")) return new String(p,StandardCharsets.UTF_16LE).replace("\u0000","").trim();
        if(t.equals("long")||t.equals("ulong")||t.equals("int")||t.equals("integer")) return signedLE(p);
        if(t.startsWith("decimal")){
            int scale=0; Matcher m=Pattern.compile("decimal\\((\\d+)\\)").matcher(t); if(m.find()) scale=Integer.parseInt(m.group(1));
            long scaled=signedLE(Arrays.copyOf(p,Math.min(8,p.length)));
            return scaled/Math.pow(10,scale);
        }
        if(t.equals("date")||t.equals("datetime")||t.equals("time")) return p;
        return p;
    }
    private static long signedLE(byte[] a){
        long v=0; int n=Math.min(8,a.length); for(int i=n-1;i>=0;i--) v=(v<<8)|(a[i]&255L);
        if(n==8 && (a[7]&0x80)!=0) return v; // Java long already represents the two's-complement bit pattern.
        return v;
    }
    private static String s(Map<String,Object> r,String k){Object v=r.get(k);return v==null?null:String.valueOf(v);}
    private static String cleanNull(String s){return s==null?null:s.trim();}
    private static int integer(Map<String,Object> r,String k){Object v=r.get(k);if(v instanceof Number)return ((Number)v).intValue();try{return Integer.parseInt(String.valueOf(v));}catch(Exception e){return 0;}}
    private static double decimal(Map<String,Object> r,String k){Object v=r.get(k);if(v instanceof Number)return ((Number)v).doubleValue();try{return Double.parseDouble(String.valueOf(v));}catch(Exception e){return 0;}}

    static boolean containsAny(String s,String... terms){for(String t:terms)if(s.contains(t))return true;return false;}
    static String titleOf(String code,String text){String k=REPORTS.get(code); if(k!=null)return k; return "PSR "+code;}
    static String decodeBest(byte[] raw){String a=new String(raw,StandardCharsets.UTF_16LE);if(printable(a)>.12)return a;String b=new String(raw,StandardCharsets.UTF_8);if(printable(b)>.12)return b;return new String(raw,StandardCharsets.ISO_8859_1);}
    static double printable(String s){if(s.isEmpty())return 0;int n=0;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='\n'||c=='\r'||c=='\t'||(c>=32&&c<127)||c>=160)n++;}return(double)n/s.length();}
    static String clean(String s){return s.replace('\u0000',' ').replaceAll("\\s+"," ").trim();}
    static String codeOf(String name,String text){Matcher m=Pattern.compile("RPT_([A-Z]\\d{3})(?:\\.PSR)?",Pattern.CASE_INSENSITIVE).matcher(text);if(m.find())return m.group(1).toUpperCase(Locale.ROOT);m=Pattern.compile("\\b([A-Z]\\d{3})\\b",Pattern.CASE_INSENSITIVE).matcher(text);while(m.find()){String c=m.group(1).toUpperCase(Locale.ROOT);if(c.charAt(0)=='D'||c.charAt(0)=='B')return c;}m=Pattern.compile("RPT_([A-Z]\\d{3})",Pattern.CASE_INSENSITIVE).matcher(name);return m.find()?m.group(1).toUpperCase(Locale.ROOT):"UNKNOWN";}
    static byte[] readAll(File f)throws IOException{try(InputStream in=new BufferedInputStream(new FileInputStream(f));ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    static int indexOf(byte[] a,byte[] n,int from){outer:for(int i=Math.max(0,from);i<=a.length-n.length;i++){for(int j=0;j<n.length;j++)if(a[i+j]!=n[j])continue outer;return i;}return -1;}
    static String readU16z(byte[] b,int q){StringBuilder s=new StringBuilder();while(q+1<b.length){int c=(b[q]&255)|((b[q+1]&255)<<8);if(c==0)break;s.append((char)c);q+=2;}return s.toString();}
    static int nextU16z(byte[] b,int q){while(q+1<b.length){int c=(b[q]&255)|((b[q+1]&255)<<8);q+=2;if(c==0)break;}return q;}
    static long u32(byte[] b,int p){return ((long)b[p]&255)|(((long)b[p+1]&255)<<8)|(((long)b[p+2]&255)<<16)|(((long)b[p+3]&255)<<24);}

    static final class ColumnDef{final String name,type;ColumnDef(String n,String t){name=n;type=t;}}
    public static final class FinancingRow{
        public final String branch,account,cif,noNsb,akad; public final double outstanding,saldoPokok,ckpn; public final int kolek,kolNsb,kolRpt,kolekLl,hariMenunggak;
        FinancingRow(String br,String a,String c,String n,String ak,double o,double sp,int k,int kn,int kr,int kl,int h,double ck){branch=br;account=a;cif=c;noNsb=n;akad=ak;outstanding=o;saldoPokok=sp;kolek=k;kolNsb=kn;kolRpt=kr;kolekLl=kl;hariMenunggak=h;ckpn=ck;}
    }
    public static final class Result{
        public final String file,code,type; public final long size; public final List<String> columns,units,dates,candidates; public final List<FinancingRow> financing;
        Result(String f,String c,String t,long s,List<String> col,List<String> u,List<String> d,List<String> ca,List<FinancingRow> fr){file=f;code=c;type=t;size=s;columns=col;units=u;dates=d;candidates=ca;financing=fr;}
    }
}
