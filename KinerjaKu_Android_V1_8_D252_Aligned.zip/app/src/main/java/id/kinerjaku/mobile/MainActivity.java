package id.kinerjaku.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.DocumentsContract;
import android.database.Cursor;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER=3001;
    private LinearLayout content;
    private TextView status, stats;
    private Button pick;
    private SnapshotDb db;

    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s);v.setTextSize(size);v.setTextColor(color);
        v.setPadding(dp(4),dp(5),dp(4),dp(5)); return v;
    }
    LinearLayout card(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16),dp(16),dp(16),dp(16));
        GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(dp(14));g.setStroke(dp(1),Color.rgb(225,230,238));c.setBackground(g);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(12));c.setLayoutParams(lp);
        return c;
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new SnapshotDb(this);build();}

    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(244,246,249));
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18),dp(18),dp(18),dp(16));header.setBackgroundColor(Color.rgb(23,59,114));
        TextView title=text("KinerjaKu",23,Color.WHITE);title.setTypeface(null,Typeface.BOLD);
        header.addView(title);header.addView(text("Daily Snapshot • PSR Offline",14,Color.WHITE));root.addView(header);

        ScrollView scroll=new ScrollView(this);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(14),dp(14),dp(90));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout imp=card();
        imp.addView(text("Import Folder PSR",21,Color.rgb(23,32,51)));
        imp.addView(text("Pilih folder laporan harian yang berisi seluruh file .PSR. Tidak membutuhkan PC, server, RAR, atau internet.",13,Color.DKGRAY));
        pick=new Button(this);pick.setText("📂  PILIH FOLDER PSR");pick.setOnClickListener(v->chooseFolder());imp.addView(pick);
        status=text("Belum ada snapshot.",13,Color.GRAY);imp.addView(status);content.addView(imp);

        LinearLayout dash=card();dash.addView(text("Database Snapshot",18,Color.rgb(23,32,51)));
        stats=text("Snapshot tersimpan: "+db.snapshotCount()+"\nPilih folder untuk import snapshot berikutnya.",14,Color.DKGRAY);dash.addView(stats);content.addView(dash);

        LinearLayout info=card();info.addView(text("Deteksi Field PSR",18,Color.rgb(23,32,51)));
        info.addView(text("KinerjaKu otomatis mencari field yang berhubungan dengan rekening, CIF/nasabah, kolektabilitas, outstanding dan saldo. Hasil ini menjadi dasar mapping analisa 20 → 21 → 22 September.",13,Color.DKGRAY));
        content.addView(info);
        setContentView(root);
    }

    void chooseFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i,PICK_FOLDER);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK_FOLDER && result==RESULT_OK && data!=null && data.getData()!=null){
            Uri tree=data.getData();
            try{getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            pick.setEnabled(false);status.setText("⏳ Membaca seluruh PSR...");
            new Thread(()->processFolder(tree)).start();
        }
    }

    void processFolder(Uri tree){
        List<PsrAnalyzer.Result> results=new ArrayList<>();
        try{
            scanDocument(tree,results);
            String folderName=folderName(tree);
            long id=db.saveSnapshot(folderName,results);
            List<SnapshotDb.Movement> movements=db.movements(id);
            Map<String,Integer> counts=new LinkedHashMap<>();
            for(PsrAnalyzer.Result r:results)counts.put(r.code,counts.getOrDefault(r.code,0)+1);
            runOnUiThread(()->showResults(folderName,results,counts,id,movements));
        }catch(Exception e){
            final String msg=e.getMessage()==null?e.toString():e.getMessage();
            runOnUiThread(()->{pick.setEnabled(true);status.setText("❌ Import gagal: "+msg);});
        }
    }

    void scanDocument(Uri doc,List<PsrAnalyzer.Result> results)throws Exception{
        String[] projection={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(doc,DocumentsContract.getTreeDocumentId(doc));
        try(Cursor c=getContentResolver().query(children,projection,null,null,null)){
            if(c==null)return;
            while(c.moveToNext()){
                String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
                Uri child=DocumentsContract.buildDocumentUriUsingTree(doc,id);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) scanDocument(child,results);
                else if(name!=null && name.toLowerCase(Locale.ROOT).endsWith(".psr")){
                    File tmp=new File(getCacheDir(),"psr_"+System.nanoTime()+".psr");
                    try(InputStream in=getContentResolver().openInputStream(child);OutputStream out=new FileOutputStream(tmp)){
                        if(in==null)continue;byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                    }
                    try{results.add(PsrAnalyzer.analyze(tmp));}finally{tmp.delete();}
                }
            }
        }
    }

    void showResults(String folder,List<PsrAnalyzer.Result> results,Map<String,Integer> counts,long id,List<SnapshotDb.Movement> movements){
        pick.setEnabled(true);
        status.setText("✅ Snapshot tersimpan: "+folder+" • "+results.size()+" PSR");
        StringBuilder s=new StringBuilder();
        s.append("Snapshot: ").append(folder).append("\n");
        s.append("File PSR: ").append(results.size()).append("\n");
        s.append("Jenis kode: ").append(counts.size()).append("\n");
        s.append("Total snapshot tersimpan: ").append(db.snapshotCount()).append("\n\n");
        for(Map.Entry<String,Integer> e:counts.entrySet())
            s.append(e.getKey()).append(" — ").append(PsrAnalyzer.REPORTS.getOrDefault(e.getKey(),"PSR "+e.getKey())).append(" : ").append(e.getValue()).append(" file\n");
        stats.setText(s.toString());

        LinearLayout mov=card();
        mov.addView(text("Perubahan Kolektabilitas",18,Color.rgb(23,32,51)));
        if(movements.isEmpty()){
            mov.addView(text(db.previousSnapshotName(id)==null ? "Belum ada snapshot sebelumnya. Import tanggal berikutnya untuk mulai perbandingan." : "Tidak ada perubahan kolektabilitas yang terdeteksi pada rekening D252.",13,Color.DKGRAY));
        }else{
            int limit=Math.min(80,movements.size());
            for(int i=0;i<limit;i++){SnapshotDb.Movement m=movements.get(i);
                String icon=m.direction.equals("MEMBURUK")?"🔴":m.direction.equals("MEMBAIK")?"🟢": "🟡";
                String oldK=m.oldK==0?"baru":String.valueOf(m.oldK), newK=String.valueOf(m.newK);
                mov.addView(text(icon+" "+m.direction+"\n"+m.account+" • "+(m.name==null?"":m.name)+"\nKol "+oldK+" → "+newK+" • Outstanding Rp "+String.format(Locale.US,"%,.0f",m.outstanding),12,Color.DKGRAY));
            }
            if(movements.size()>limit)mov.addView(text("... dan "+(movements.size()-limit)+" perubahan lainnya",12,Color.GRAY));
        }
        content.addView(mov,2);

        LinearLayout detail=card();detail.addView(text("PSR & Field Penting",18,Color.rgb(23,32,51)));
        int shown=0;
        for(PsrAnalyzer.Result r:results){
            if(shown++>=120) break;
            StringBuilder row=new StringBuilder();
            row.append(r.file).append("\n").append(r.code).append(" • ").append(r.type).append("\n");
            row.append("DataWindow: ").append(r.columns.size()).append(" kolom");
            if(!r.financing.isEmpty()){
                row.append("\n📊 D252 rows: ").append(r.financing.size());
                int lim=Math.min(3,r.financing.size());
                for(int i=0;i<lim;i++){PsrAnalyzer.FinancingRow x=r.financing.get(i);
                    row.append("\n   ").append(x.account).append(" | ").append(x.cif).append(" | Kol ").append(x.kolek).append(" | Rp ").append(String.format(Locale.US,"%,.0f",x.outstanding));
                }
            }
            if(!r.candidates.isEmpty()){
                row.append("\n🔎 Kandidat field: ");
                int lim=Math.min(8,r.candidates.size());
                for(int i=0;i<lim;i++){if(i>0)row.append(" | ");row.append(r.candidates.get(i));}
            }
            TextView tv=text(row.toString(),12,Color.DKGRAY);tv.setPadding(dp(4),dp(8),dp(4),dp(8));detail.addView(tv);
        }
        content.addView(detail,2);
    }

    String folderName(Uri tree){
        try{
            Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
            String[] p={DocumentsContract.Document.COLUMN_DISPLAY_NAME};
            try(Cursor c=getContentResolver().query(doc,p,null,null,null)){
                if(c!=null&&c.moveToFirst()){
                    String n=c.getString(0);if(n!=null&&!n.isEmpty())return n;
                }
            }
        }catch(Exception ignored){}
        return "Snapshot";
    }
}
