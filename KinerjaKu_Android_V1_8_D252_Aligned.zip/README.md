# KinerjaKu Android V1.8

V1.6 mulai membaca **record pembiayaan D252** dari binary PSR PowerBuilder, bukan hanya metadata. PSR memang menyimpan definisi DataWindow dan data snapshot di dalam file; ini sesuai dokumentasi PowerBuilder.

## D252 yang dibaca
- Kode cabang
- Nomor rekening (ACCNBR)
- Nama/CIF (CIFNM)
- Nomor nasabah (NO_NSB)
- Nomor akad
- SALDO_AKHIR sebagai outstanding (skala 2 desimal)
- SALDO_POKOK
- KOL_NSB
- KOL_RPT
- KOLEK
- KOLEK_LL
- HARI_MENUNGGAK
- CKPN

## Snapshot harian
Setiap folder yang diimport menjadi snapshot SQLite. Record D252 disimpan per rekening sehingga snapshot berikutnya dapat dibandingkan dengan snapshot sebelumnya.

## Build APK
Buka folder project ini di Android Studio, tunggu Gradle Sync, lalu **Build > Build APK(s)**.

APK debug: `app/build/outputs/apk/debug/app-debug.apk`

## Pengujian yang disarankan
Import folder **20-09-2026**, kemudian **21-09-2026**, kemudian **22-09-2026**. Setelah snapshot kedua dan seterusnya, kartu **Perubahan Kolektabilitas** akan menampilkan rekening D252 yang berubah.

Catatan: mapping D252 divalidasi terhadap PSR yang diberikan. PSR kode lain belum boleh diasumsikan memiliki struktur record yang sama.


## V1.8 — D252 alignment fix
Pada format PSR D252 yang diuji, `KD_CAB` disimpan sekali setelah row marker, sedangkan payload berikutnya dimulai dari `ACCNBR`. Decoder V1.8 melewati kolom `*_KD_CAB` pada definisi DataWindow agar field `ACCNBR`, `CIFNM`, `NO_NSB`, `SALDO_AKHIR`, `KOL_NSB`, `KOL_RPT`, `KOLEK`, dan `KOLEK_LL` tidak bergeser.

Contoh PSR 22-09-2026 yang diuji: MASDAR LUTHFI / 07305090006712 / 0002914168 menghasilkan SALDO_AKHIR Rp218.666.426 dan KOLEK 1.
