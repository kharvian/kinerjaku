# KinerjaKu Android V1.8

## Perbaikan utama
- D252 sekarang dibaca berdasarkan **definisi kolom DataWindow yang tertanam di PSR**, bukan berdasarkan posisi/heuristik semata.
- Decimal PowerBuilder 16-byte untuk `decimal(2)` dan `decimal(5)` dikonversi menggunakan scale dari definisi kolom.
- Field D252 yang dipakai untuk analisa: `ACCNBR`, `CIFNM`, `NO_NSB`, `NOMOR_AKAD`, `SALDO_AKHIR`, `SALDO_POKOK`, `KOL_NSB`, `KOL_RPT`, `KOLEK`, `KOLEK_LL`, `HARI_MENUNGGAK`, `CKPN`.
- Perbandingan snapshot tetap menggunakan nomor rekening sebagai kunci.

## Build
Android Studio → Open project → Build → Rebuild Project → Build APK(s).

APK debug: `app/build/outputs/apk/debug/app-debug.apk`

## Uji yang disarankan
Import berurutan 20-09-2026, 21-09-2026, 22-09-2026. Pastikan pada kartu D252 muncul nilai Kol 1/2/3/... sesuai isi PSR, bukan `Kol 0`.


### Validasi D252 V1.8
PSR `RPT_D252.PSR` yang diuji memiliki 63 kolom. Nilai `KD_CAB` berada di row payload terpisah; decoder tidak lagi memasukkannya sebagai payload kolom pertama. Hasil validasi: ACCNBR `07305090006712`, CIFNM `MASDAR LUTHFI`, NO_NSB `0002914168`, SALDO_AKHIR `218666426`, KOL_NSB `1`, KOL_RPT `1`, KOLEK `1`, KOLEK_LL `1`.
